set-DisplayResolution -Width 3440 -Height 1440 ;
cd "C:\PS Scripts\nircmd\" ; .\nircmd.exe setdefaultsounddevice "LG ULTRAWIDE" 1
set-DisplayResolution -Width 1920 -Height 1080 ;
cd "C:\PS Scripts\nircmd\" ; .\nircmd.exe setdefaultsounddevice "SAMSUNG" 1